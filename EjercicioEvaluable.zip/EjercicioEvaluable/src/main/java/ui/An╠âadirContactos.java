package ui;

import data.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class AñadirContactos extends JFrame {
    private JPanel Jpanel;
    private JTextField correo;
    private JTextField pais;
    private JTextField plataforma;
    private JLabel contactos;
    private JButton añadir;
    private JPanel root;

    private final List<Usuario> users = new ArrayList<>();

    public AñadirContactos() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("CONTACTOS");
         setContentPane(root);
        setLocationRelativeTo(null);
        setResizable(false);
        this.setSize(800, 600);
        setVisible(true);
    }

    private void attachListeners() {
        pais.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        correo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        plataforma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    public void start() {
        this.setVisible(true);
    }
}
