package ui;

import javax.swing.*;

public class RegistroContactos {
    private JPanel Jpanel;
    private JTable tabla;

    public void strat() {
        this.setVisible(true);
    }

    private void setVisible(boolean b) {
    }
}
