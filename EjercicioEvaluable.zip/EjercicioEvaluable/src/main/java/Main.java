import ui.AñadirContactos;
import ui.RegistroContactos;

public class Main {
    public static void main(String[] args) {
        (new AñadirContactos()).start();

    }
}
