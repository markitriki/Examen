package data;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
public class Usuario {


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class User {
        private String pais;
        private String Correo;
        private String plataforma;
    }
}
